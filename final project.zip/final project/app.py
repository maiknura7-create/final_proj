import streamlit as st
import json
import project

st.set_page_config(page_title="Smart Fridge AI", page_icon="🥗", layout="wide")


def get_emoji(item_name):
    item = item_name.lower()
    if "chicken" in item: return "🍗"
    if "tomato" in item: return "🍅"
    if "milk" in item: return "🥛"
    if "noodle" in item: return "🍝"
    if "rice" in item: return "🍚"
    return "📦"

st.sidebar.header("👤 Personal Profile")
weight_ui = st.sidebar.number_input("Weight (kg)", value=75)
people_ui = st.sidebar.number_input("Cooking for", value=2, min_value=1)
activity_ui = st.sidebar.selectbox(
    "Activity Level",
    ["Sedentary", "Moderate", "Highly Active"]
)

if "final_state" not in st.session_state:
    st.title("🧊 Your Smart Fridge")
    st.markdown("Select your profile on the left and generate a custom recipe.")

    try:
        with open("fridge.json", "r") as f:
            fridge_data = json.load(f)

        cols = st.columns(len(fridge_data["inventory"]))
        for idx, item in enumerate(fridge_data["inventory"]):
            with cols[idx]:
                st.metric(
                    label=f"{get_emoji(item['item'])} {item['item']}",
                    value=f"{item['mass_g']}g"
                )
                days = item['expiry_days']
                if days <= 2:
                    st.error(f"⌛ Expires in {days} days")
                else:
                    st.success(f"⌛ {days} days left")
    except FileNotFoundError:
        st.error("fridge.json not found! Please ensure it exists in the directory.")

    if st.button("🍳 Generate Detailed Recipe", type="primary"):
        with st.spinner(f"Chef is scaling recipe for {people_ui} people..."):
            user_data = {
                "weight": weight_ui,
                "people": people_ui,
                "activity": activity_ui
            }

            st.session_state.final_state = project.app.invoke({
                "user_profile": user_data,
                "ingredients_input": ""
            })
            st.rerun()

else:
    res = st.session_state.final_state

    if st.button("⬅️ Back to Fridge"):
        del st.session_state.final_state
        st.rerun()

    st.title(f"🍽️ {res['recipe'].recipe_name}")

    col1, col2 = st.columns([1, 1.5])

    with col1:
        st.subheader("🛒 Ingredients (Total)")
        for ing in res['recipe'].ingredients_used:
            st.markdown(f"{get_emoji(ing)} **{ing}**")

        st.divider()
        st.subheader(f"💪 Fitness & Nutrition (per person)")
        st.write(f"🔥 **Calories:** {res['nutrition'].calories} kcal")
        st.write(f"🥩 **Protein:** {res['nutrition'].protein_g}g")
        st.write(f"🍞 **Carbs:** {res['nutrition'].carbs_g}g")
        st.write(f"🥑 **Fat:** {res['nutrition'].fat_g}g")
        st.write(f"🎯 **Goal:** {res['nutrition'].fitness_goal}")
        st.write(f"⭐ **Health Score:** {res['nutrition'].health_score}/10")

        # Display the professional advice in a nice box
        st.info(f"💡 {res['nutrition'].pro_advice}")

    with col2:
        st.subheader("👨‍🍳 Detailed Instructions")
        for i, step in enumerate(res['recipe'].instructions):
            st.markdown(f"**Step {i + 1}**: {step}")

        st.divider()
        st.subheader("🧊 Leftovers in Fridge")
        for item in res['leftovers']:
            if isinstance(item, dict):
                name = item['item']
                mass = item['mass']
                days = item['expiry']
                color = "red" if days <= 2 else "#808080"
                st.markdown(
                    f"{get_emoji(name)} **{name}**: {mass}g left "
                    f"(<span style='color:{color}'>{days} days remaining</span>)",
                    unsafe_allow_html=True
                )
            else:
                st.write(f"✅ {item}")