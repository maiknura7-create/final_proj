import os
import json
import re
from typing import List, TypedDict
from pydantic import BaseModel, Field
from langchain_groq import ChatGroq
from langgraph.graph import StateGraph, END
import prompts

os.environ["GROQ_API_KEY"] = "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"
llm = ChatGroq(model="llama-3.3-70b-versatile", temperature=0.7)


class Recipe(BaseModel):
    recipe_name: str = Field(description="Name of the dish")
    ingredients_used: List[str] = Field(description="List of ingredients and MASS used")
    instructions: List[str] = Field(description="Step-by-step directions")
    prep_time: str = Field(description="Estimated time to prepare")


class NutritionInfo(BaseModel):
    calories: int = Field(description="Calories per serving")
    protein_g: float = Field(description="Grams of protein")
    carbs_g: float = Field(description="Grams of carbohydrates")
    fat_g: float = Field(description="Grams of fat")
    health_score: str = Field(description="Rating from 1-10")
    fitness_goal: str = Field(description="Best for Muscle Gain, Mass Gain, or Maintenance")
    digestibility: str = Field(description="How easy it is to digest")
    satiety_level: str = Field(description="How full it makes you feel")
    pro_advice: str = Field(description="Advice based on user weight and activity")


class AgentState(TypedDict):
    user_profile: dict
    ingredients_input: str
    recipe: Recipe
    nutrition: NutritionInfo
    leftovers: List[dict]


def inventory_manager_node(state: AgentState):
    try:
        with open("fridge.json", "r") as f:
            data = json.load(f)
        inventory_items = [f"{i['item']} ({i['mass_g']}g)" for i in data["inventory"]]
        return {"ingredients_input": " | ".join(inventory_items)}
    except FileNotFoundError:
        return {"ingredients_input": "No fridge data found."}

def chef_node(state: AgentState):
    profile = state.get("user_profile", {})
    num_people = profile.get("people", 1)

    structured_llm = llm.with_structured_output(Recipe)

    human_msg = f"Inventory: {state['ingredients_input']}. COOK FOR {num_people} PEOPLE. Scale ingredients perfectly."

    return {"recipe": structured_llm.invoke([
        ("system", prompts.RECIPE_GENERATOR_PROMPT),
        ("human", human_msg)
    ])}


def dietician_node(state: AgentState):
    profile = state.get("user_profile", {})
    u_weight = profile.get("weight", 70)
    u_activity = profile.get("activity", "Moderate")

    structured_llm = llm.with_structured_output(NutritionInfo)

    human_msg = f"Recipe: {state['recipe'].recipe_name}. User weighs {u_weight}kg and is {u_activity}."

    return {"nutrition": structured_llm.invoke([
        ("system", prompts.NUTRITION_ANALYZER_PROMPT),
        ("human", human_msg)
    ])}

def remaining_inventory_node(state: AgentState):
    with open("fridge.json", "r") as f:
        data = json.load(f)

    leftover_info = []
    used_text = " ".join(state['recipe'].ingredients_used).lower()

    for i in data["inventory"]:
        item_name = i['item'].lower()
        original_mass = i['mass_g']
        expiry = i['expiry_days']

        match = re.search(r'(\d+)g\s+' + re.escape(item_name), used_text)
        used_mass = int(match.group(1)) if match else 0

        remaining = max(0, original_mass - used_mass)

        leftover_info.append({
            "item": i['item'],
            "mass": remaining,
            "expiry": expiry
        })

    return {"leftovers": leftover_info}


builder = StateGraph(AgentState)
builder.add_node("inventory", inventory_manager_node)
builder.add_node("chef", chef_node)
builder.add_node("dietician", dietician_node)
builder.add_node("leftovers", remaining_inventory_node)
builder.set_entry_point("inventory")
builder.add_edge("inventory", "chef")
builder.add_edge("chef", "dietician")
builder.add_edge("dietician", "leftovers")
builder.add_edge("leftovers", END)
app = builder.compile()

if __name__ == "__main__":
    my_profile = {"weight": 75, "people": 2, "activity": "Highly Active"}
    print(f"Analyzing for {my_profile['people']} people ({my_profile['activity']})...")
    final_state = app.invoke({"user_profile": my_profile, "ingredients_input": ""})

    print("\n" + "=" * 40)
    print(f"RECIPE: {final_state['recipe'].recipe_name}")
    print(f"PREP TIME: {final_state['recipe'].prep_time}")
    print(f"USED: {', '.join(final_state['recipe'].ingredients_used)}")
    print(f"INSTRUCTIONS: {'. '.join(final_state['recipe'].instructions)}")

    print("-" * 40)
    print("NUTRITIONAL BREAKDOWN (Per Serving):")
    print(f" - Calories: {final_state['nutrition'].calories} kcal")
    print(f" - Protein:  {final_state['nutrition'].protein_g}g")
    print(f" - Carbs:    {final_state['nutrition'].carbs_g}g")
    print(f" - Fat:      {final_state['nutrition'].fat_g}g")

    print("-" * 40)
    print("FITNESS INSIGHTS:")
    print(f" - Goal:       {final_state['nutrition'].fitness_goal}")
    print(f" - Digestion:  {final_state['nutrition'].digestibility}")
    print(f" - Fullness:   {final_state['nutrition'].satiety_level}")
    print(f" - Health:     {final_state['nutrition'].health_score}/10")
    print(f" - Advice:     {final_state['nutrition'].pro_advice}")

    print("-" * 40)
    print("REMAINING IN FRIDGE:")
    for left in final_state['leftovers']:
        print(f" * {left}")
    print("=" * 40)